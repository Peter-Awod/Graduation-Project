

class User {
  final int userId;
  final String username;
  final String email;
  final String phone;
  final String gender;
  final String password;
  final String birthday;

  User({
    this.userId=0,
     this.username='',
     this.password='',
     this.email='',
      this.phone='',
      this.gender='',
      this.birthday='',
  });
}

