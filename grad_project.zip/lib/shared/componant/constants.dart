import 'package:flutter/material.dart';

class Constants {
  // Constant Color
  static const Color kPinkColor = Color(0xFF0061D0);
  static const Color kCyanColor = Color(0xFF1D7783);
  static const Color kGreenColor = Color(0xFF09FBD3);
  static const Color kBlackColor = Color(0xFF19191B);
  static const Color kYellowColor = Color(0xFFF2A33A);
  static const Color kWhiteColor = Color(0xFFFFFFFF);
  static const Color kGreyColor = Color(0xFF767680);
}

//0xff55598d